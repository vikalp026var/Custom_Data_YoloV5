# yolo v5 car > 2023-12-19 10:23pm
https://universe.roboflow.com/po-thaxt/yolo-v5-car

Provided by a Roboflow user
License: Public Domain

